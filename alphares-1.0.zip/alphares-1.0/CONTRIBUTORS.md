## Contributors

The following people have contributed to alphares's development:

* Brayden Carlson
* TeoVR-YT

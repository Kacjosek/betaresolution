#pragma once

#include <windows.h>

namespace Color {
    const COLORREF PURPLE = RGB(43, 45, 92);
    const COLORREF DARK_PURPLE = RGB(35, 35, 79);
    const COLORREF LIGHT_PURPLE = RGB(93, 107, 238);
    const COLORREF WHITE = RGB(255, 255, 255);
}

#pragma once

#ifdef APSTUDIO_INVOKED
    #ifndef APSTUDIO_READONLY_SYMBOLS
        #define _APS_NEXT_RESOURCE_VALUE        101
        #define _APS_NEXT_COMMAND_VALUE         40001
        #define _APS_NEXT_CONTROL_VALUE         1001
        #define _APS_NEXT_SYMED_VALUE           101
    #endif
#endif

#define IDR_ICON           2000

#define IDC_HEIGHT_LABEL   2005
#define IDC_WIDTH_LABEL    2010
#define IDC_FPS_LABEL      2015

#define IDC_HEIGHT_EDIT    2020
#define IDC_WIDTH_EDIT     2025
#define IDC_FPS_EDIT       2030

#define IDC_GROUP_RADIO    2035
#define IDC_FS_RADIO       2040
#define IDC_WFS_RADIO      2045
#define IDC_W_RADIO        2050

#define IDC_RO_CHECKBOX    2055
#define IDC_APPLY_BUTTON   2060
